// ==================================================
// assets/api.js
// Helper komunikasi Frontend → Backend VillageHub
// ==================================================

const API_BASE = new URL('../api', document.currentScript.src).pathname;

// ==================================================
// HELPER UTAMA
// ==================================================
async function apiFetch(endpoint, options = {}) {
  const isFormData = options.body instanceof FormData;

  const defaultOptions = {
    credentials: 'include',
    headers: isFormData ? {} : { 'Content-Type': 'application/json' }
  };
  const finalOptions = { ...defaultOptions, ...options };

  try {
    const response = await fetch(API_BASE + endpoint, finalOptions);
    return await response.json();
  } catch (error) {
    console.error('API Error:', error);
    return { success: false, message: 'Gagal terhubung ke server' };
  }
}

// ==================================================
// AUTH — Login, Register, Logout, Cek Login
// ==================================================
async function login(email, password) {
  return await apiFetch('/auth/login.php', {
    method: 'POST',
    body: JSON.stringify({ email, password })
  });
}

async function register(dataUser) {
  return await apiFetch('/auth/register.php', {
    method: 'POST',
    body: JSON.stringify(dataUser)
  });
}

async function logout() {
  return await apiFetch('/auth/logout.php', { method: 'POST' });
}

async function cekLogin() {
  return await apiFetch('/auth/check.php', { method: 'GET' });
}

// ==================================================
// KATEGORI
// ==================================================
async function getKategori() {
  return await apiFetch('/kategori/list.php', { method: 'GET' });
}

// ==================================================
// PUBLIC (TANPA LOGIN)
// ==================================================
async function getAduanPublic(id_kategori = 0) {
  let url = '/public/aduan_terbaru.php';
  if (id_kategori > 0) url += '?kategori=' + id_kategori;
  return await apiFetch(url, { method: 'GET' });
}

// ==================================================
// USER — Kirim Aduan, Riwayat, Detail, Dashboard
// ==================================================
async function kirimAduan(formData) {
  try {
    const res = await fetch(API_BASE + '/user/aduan_create.php', {
      method: 'POST',
      credentials: 'include',
      body: formData
    });
    return await res.json();
  } catch (error) {
    console.error(error);
    return { success: false, message: 'Gagal terhubung' };
  }
}

async function getAduanSaya() {
  return await apiFetch('/user/aduan_list.php', { method: 'GET' });
}

async function getAduanDetail(id) {
  return await apiFetch('/user/aduan_detail.php?id=' + id, { method: 'GET' });
}

async function getDashboardUser() {
  return await apiFetch('/user/dashboard.php', { method: 'GET' });
}

// ==================================================
// ADMIN — Dashboard, Aduan, Balas, Riwayat
// ==================================================
async function getDashboardAdmin() {
  return await apiFetch('/admin/dashboard.php', { method: 'GET' });
}

async function getAduanAdmin(filter = {}) {
  const params = new URLSearchParams(filter).toString();
  const url = '/admin/aduan_list.php' + (params ? '?' + params : '');
  return await apiFetch(url, { method: 'GET' });
}

async function balasAduan(id_aduan, balasan) {
  return await apiFetch('/admin/aduan_balas.php', {
    method: 'POST',
    body: JSON.stringify({ id_aduan, balasan })
  });
}

async function getRiwayatAdmin(page = 1, limit = 10, status = '') {
  let url = `/admin/riwayat.php?page=${page}&limit=${limit}`;
  if (status) url += `&status=${status}`;
  return await apiFetch(url, { method: 'GET' });
}

// ==================================================
// UTILITY — Redirect & Alert
// ==================================================

// PERBAIKAN: Ubah URL redirect (Hapus /villagehub2/)
function redirectByRole(role) {
  if (role === 'admin') {
    window.location.href = '/admin/dashboard.php';
  } else if (role === 'warga') {
    window.location.href = '/user/beranda.php';
  } else {
    alert('Role tidak dikenali!');
  }
}

// PERBAIKAN: Ubah URL redirect (Hapus /villagehub2/)
function cekLoginAtauRedirect(roleYangDiizinkan = null) {
  cekLogin().then(res => {
    if (!res.success) {
      window.location.href = '/login.php';
      return;
    }
    if (roleYangDiizinkan && res.user.role !== roleYangDiizinkan) {
      alert('Akses ditolak');
      window.location.href = '/login.php';
    }
  });
}

// PERBAIKAN: Ubah URL redirect (Hapus /villagehub2/)
function logoutDanRedirect() {
  if (!confirm('Yakin ingin logout?')) {
    return;
  }
  window.location.href = '/logout.php';
}

// PERBAIKAN: Ubah URL redirect (Hapus /villagehub2/)
function logoutLangsung() {
  window.location.href = '/logout.php';
}

// ==================================================
// USER — Update Profil & Foto
// ==================================================
async function updateProfil(dataUser) {
  return await apiFetch('/user/update_profil.php', {
    method: 'POST',
    body: JSON.stringify(dataUser)
  });
}

async function updateFotoProfil(formData) {
  try {
    const res = await fetch(API_BASE + '/user/update_foto.php', {
      method: 'POST',
      credentials: 'include',
      body: formData
    });
    return await res.json();
  } catch (error) {
    console.error(error);
    return { success: false, message: 'Gagal terhubung' };
  }
}

// ==================================================
// USER — Hapus Aduan
// ==================================================
async function hapusAduan(id_aduan) {
  return await apiFetch('/user/aduan_delete.php', {
    method: 'POST',
    body: JSON.stringify({ id_aduan })
  });
}

// ============ HAPUS FOTO PROFIL ============
async function hapusFotoProfil() {
  const formData = new FormData();
  formData.append('hapus_foto', '1');

  try {
    const res = await fetch(API_BASE + '/user/update_foto.php', {
      method: 'POST',
      credentials: 'include',
      body: formData
    });
    return await res.json();
  } catch (error) {
    console.error(error);
    return { success: false, message: 'Gagal terhubung' };
  }
}